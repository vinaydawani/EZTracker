from PyQt5.QtWidgets import QTabWidget, QLabel, QVBoxLayout, QWidget, QScrollArea
from PyQt5.QtCore import *
from qgis.gui import QgsMapToolIdentify
from qgis.utils import iface
from qgis.core import *
from qgis.PyQt.QtGui import *

class SelectTool(QgsMapToolIdentify):
    def __init__(self, canvas, attr, rang):
        QgsMapToolIdentify.__init__(self, canvas)
        self.canvas = canvas
        self.selected = []
        self.highlight = [] #different color is a good idea
        self.currentLayer = None
        self.attribute = attr
        self.range = rang
    def canvasReleaseEvent(self, event):
        if not iface.activeLayer() is self.currentLayer:
            self.selected = []
            self.currentLayer = iface.activeLayer()
        l = iface.activeLayer()
        results = self.identify(event.x(), event.y(), [l], \
            QgsMapToolIdentify.TopDownStopAtFirst)
        if len(results) > 0:
            for r in results:
                id = r.mFeature.id()
                if not id in self.selected:
                    self.selected.append(id)
                else:
                    self.selected.remove(id)
        else:
            self.selected = []
        l.selectByIds(self.selected)


    def highlightFeatures(self, layer, attr, rang):

        self.highlight = []
        selection = layer.selectedFeatures()

        if (len(selection) >= 1):
            lowAttr = selection[0][attr]
            highAttr = selection[0][attr]
            
            for i in range(len(selection)):

                f = selection[i]

                if (lowAttr > f[attr]):
                    lowAttr = f[attr]
                if (highAttr < f[attr]):
                    highAttr = f[attr]

            lowAttr = lowAttr-rang
            highAttr =highAttr+rang

#########################
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            renderer = QgsRuleBasedRenderer(symbol)
            symbol.setColor(QColor.fromRgb(180, 180, 180))

            # get the root rule
            root_rule = renderer.rootRule()

            # create clone of the default rule
            rule = root_rule.children()[0].clone()

            # set the label, expression and color
            rule.setLabel("Similar Attributes!")
            a=" \""+attr+"\""
            rule.setFilterExpression( a +" >= "+str(lowAttr)+" and " +a+"<="+str(highAttr))
            rule.symbol().setColor(QColor("orange"))

            # append the rule to the list of rules
            root_rule.appendChild(rule)
            # apply the renderer
            layer.setRenderer(renderer)
####################################
            
            for f in layer.getFeatures():
                if ((f[attr] >= lowAttr) and (f[attr]<= highAttr)):

                    self.highlight.append(f.id())

        else:
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            renderer = QgsRuleBasedRenderer(symbol)
            symbol.setColor(QColor.fromRgb(180, 180, 180))

            # get the root rule
            root_rule = renderer.rootRule()

            # create clone of the default rule
            rule = root_rule.children()[0].clone()

            # append the rule to the list of rules
            root_rule.appendChild(rule)
            # apply the renderer
            layer.setRenderer(renderer)
            


                
            

        
        
